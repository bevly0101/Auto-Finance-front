import Logo from '../common/Logo';

export default Logo;
