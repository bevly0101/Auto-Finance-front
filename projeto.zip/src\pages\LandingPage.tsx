import React from 'react';
import LandingPageComponent from '@/components/landing-page/LandingPagecomponent';

const LandingPage: React.FC = () => {
  return <LandingPageComponent />;
};

export default LandingPage;