import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Cookie } from 'lucide-react';

const CookieConsentModal: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('cookie_consent');
    if (!consent) {
      setIsVisible(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('cookie_consent', 'true');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-gray-800 bg-opacity-90 text-white p-4 z-50 flex items-center justify-between flex-wrap">
      <div className="flex items-center space-x-3">
        <Cookie className="h-6 w-6 text-yellow-400" />
        <p className="text-sm">
          Nós utilizamos cookies para melhorar sua experiência. Ao continuar a navegar, você concorda com a nossa{' '}
          <Link to="/privacy" className="underline hover:text-yellow-400">
            Política de Privacidade
          </Link>.
        </p>
      </div>
      <button
        onClick={handleAccept}
        className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg mt-2 sm:mt-0"
      >
        Aceitar e Fechar
      </button>
    </div>
  );
};

export default CookieConsentModal;