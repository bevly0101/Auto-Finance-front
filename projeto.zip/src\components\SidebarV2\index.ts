export { default } from './SidebarV2';
export { default as SidebarV2 } from './SidebarV2';

